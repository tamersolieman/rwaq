# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.6.38)
# Database: rwaq
# Generation Time: 2018-04-14 16:53:38 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`)
VALUES
	(1,'هواتف ذكية','2018-04-13 19:47:00','2018-04-13 20:15:09'),
	(2,'سيارات','2018-04-13 20:14:00','2018-04-13 20:14:54'),
	(3,'عقارات','2018-04-13 20:14:44','2018-04-13 20:14:44'),
	(4,'إلكترونيات','2018-04-14 11:41:52','2018-04-14 11:41:52'),
	(5,'أثاث','2018-04-14 11:41:59','2018-04-14 11:41:59'),
	(6,'وظائف','2018-04-14 11:42:06','2018-04-14 11:42:06');

/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table countries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`)
VALUES
	(1,'مصر','2018-04-13 19:47:00','2018-04-13 20:15:30'),
	(2,'السعودية','2018-04-13 20:15:39','2018-04-13 20:15:39'),
	(3,'البحرين','2018-04-13 20:15:49','2018-04-13 20:15:49'),
	(4,'الكويت','2018-04-13 20:15:55','2018-04-13 20:15:55'),
	(5,'قطر','2018-04-13 20:16:01','2018-04-13 20:16:01'),
	(6,'الإمارات','2018-04-13 20:16:07','2018-04-13 20:16:07'),
	(7,'تونس','2018-04-13 20:16:13','2018-04-13 20:16:13'),
	(8,'السودان','2018-04-13 20:16:19','2018-04-13 20:16:19'),
	(9,'الجزائر','2018-04-13 20:16:27','2018-04-13 20:16:27'),
	(10,'المغرب','2018-04-13 20:16:34','2018-04-13 20:16:34'),
	(11,'موريتانيا','2018-04-13 20:16:43','2018-04-13 20:16:43');

/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table data_rows
# ------------------------------------------------------------

DROP TABLE IF EXISTS `data_rows`;

CREATE TABLE `data_rows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data_type_id` int(10) unsigned NOT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `browse` tinyint(1) NOT NULL DEFAULT '1',
  `read` tinyint(1) NOT NULL DEFAULT '1',
  `edit` tinyint(1) NOT NULL DEFAULT '1',
  `add` tinyint(1) NOT NULL DEFAULT '1',
  `delete` tinyint(1) NOT NULL DEFAULT '1',
  `details` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `data_rows_data_type_id_foreign` (`data_type_id`),
  CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `data_rows` WRITE;
/*!40000 ALTER TABLE `data_rows` DISABLE KEYS */;

INSERT INTO `data_rows` (`id`, `data_type_id`, `field`, `type`, `display_name`, `required`, `browse`, `read`, `edit`, `add`, `delete`, `details`, `order`)
VALUES
	(1,1,'id','number','ID',1,0,0,0,0,0,'',1),
	(2,1,'name','text','Name',1,1,1,1,1,1,'',2),
	(3,1,'email','text','Email',1,1,1,1,1,1,'',3),
	(4,1,'password','password','Password',1,0,0,1,1,0,'',4),
	(5,1,'remember_token','text','Remember Token',0,0,0,0,0,0,'',5),
	(6,1,'created_at','timestamp','Created At',0,1,1,0,0,0,'',6),
	(7,1,'updated_at','timestamp','Updated At',0,0,0,0,0,0,'',7),
	(8,1,'avatar','image','Avatar',0,1,1,1,1,1,'',8),
	(9,1,'user_belongsto_role_relationship','relationship','Role',0,1,1,1,1,0,'{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsTo\",\"column\":\"role_id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"roles\",\"pivot\":\"0\"}',10),
	(10,1,'user_belongstomany_role_relationship','relationship','Roles',0,1,1,1,1,0,'{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"user_roles\",\"pivot\":\"1\"}',11),
	(11,1,'locale','text','Locale',0,1,1,1,1,0,'',12),
	(12,2,'id','number','ID',1,0,0,0,0,0,'',1),
	(13,2,'name','text','Name',1,1,1,1,1,1,'',2),
	(14,2,'created_at','timestamp','Created At',0,0,0,0,0,0,'',3),
	(15,2,'updated_at','timestamp','Updated At',0,0,0,0,0,0,'',4),
	(16,3,'id','number','ID',1,0,0,0,0,0,'',1),
	(17,3,'name','text','Name',1,1,1,1,1,1,'',2),
	(18,3,'created_at','timestamp','Created At',0,0,0,0,0,0,'',3),
	(19,3,'updated_at','timestamp','Updated At',0,0,0,0,0,0,'',4),
	(20,3,'display_name','text','Display Name',1,1,1,1,1,1,'',5),
	(21,1,'role_id','text','Role',1,1,1,1,1,1,'',9),
	(22,4,'id','text','Id',1,0,0,0,0,0,NULL,1),
	(23,4,'name','text','Name',1,1,1,1,1,1,'{\"validation\":{\"rule\":\"required|max:200\"}}',2),
	(24,4,'created_at','timestamp','Created At',0,1,0,0,0,0,NULL,3),
	(25,4,'updated_at','timestamp','Updated At',0,0,0,0,0,0,NULL,4),
	(26,5,'id','text','Id',1,0,0,0,0,0,NULL,1),
	(27,5,'name','text','Name',1,1,1,1,1,1,'{\"validation\":{\"rule\":\"required|max:100\"}}',2),
	(28,5,'created_at','timestamp','Created At',0,1,0,0,0,0,NULL,3),
	(29,5,'updated_at','timestamp','Updated At',0,0,0,0,0,0,NULL,4),
	(58,8,'id','text','Id',1,0,0,0,0,0,NULL,1),
	(59,8,'title','image','Title',1,1,1,1,1,1,NULL,2),
	(60,8,'product_id','text','Product Id',1,1,1,1,1,0,NULL,3),
	(61,8,'created_at','timestamp','Created At',0,0,0,0,0,0,NULL,4),
	(62,8,'updated_at','timestamp','Updated At',0,0,0,0,0,0,NULL,5),
	(71,8,'image_belongsto_product_relationship','relationship','Product',0,1,1,1,1,1,'{\"model\":\"App\\\\Product\",\"table\":\"products\",\"type\":\"belongsTo\",\"column\":\"product_id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"categories\",\"pivot\":\"0\"}',6),
	(87,11,'id','text','Id',1,0,0,0,0,0,NULL,1),
	(88,11,'title','text','Title',0,1,1,1,1,1,'{\"validation\":{\"rule\":\"required\"}}',3),
	(89,11,'text','text_area','Text',0,1,1,1,1,1,'{\"validation\":{\"rule\":\"required\"}}',4),
	(90,11,'price','number','Price',0,1,1,1,1,1,'{\"validation\":{\"rule\":\"required\"}}',5),
	(91,11,'is_active','select_dropdown','Is Active',0,1,1,1,1,1,'{\"default\":\"0\",\"options\":{\"0\":\"No\",\"1\":\"Yes\"}}',6),
	(92,11,'user_id','text','User Id',0,1,1,1,1,1,NULL,9),
	(93,11,'country_id','text','Country Id',0,1,1,1,1,1,NULL,10),
	(94,11,'category_id','text','Category Id',0,1,1,1,1,1,NULL,11),
	(95,11,'created_at','timestamp','Created At',0,0,0,0,0,0,NULL,12),
	(96,11,'updated_at','timestamp','Updated At',0,0,0,0,0,0,NULL,13),
	(97,11,'product_belongsto_user_relationship','relationship','User',0,1,1,1,1,1,'{\"model\":\"App\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"user_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\"}',7),
	(98,11,'product_belongsto_category_relationship','relationship','Category',0,1,1,1,1,1,'{\"model\":\"App\\\\Category\",\"table\":\"categories\",\"type\":\"belongsTo\",\"column\":\"category_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\"}',2),
	(99,11,'product_belongsto_country_relationship','relationship','Country',0,1,1,1,1,1,'{\"model\":\"App\\\\Country\",\"table\":\"countries\",\"type\":\"belongsTo\",\"column\":\"country_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\"}',8);

/*!40000 ALTER TABLE `data_rows` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table data_types
# ------------------------------------------------------------

DROP TABLE IF EXISTS `data_types`;

CREATE TABLE `data_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT '0',
  `server_side` tinyint(4) NOT NULL DEFAULT '0',
  `details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `data_types_name_unique` (`name`),
  UNIQUE KEY `data_types_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `data_types` WRITE;
/*!40000 ALTER TABLE `data_types` DISABLE KEYS */;

INSERT INTO `data_types` (`id`, `name`, `slug`, `display_name_singular`, `display_name_plural`, `icon`, `model_name`, `policy_name`, `controller`, `description`, `generate_permissions`, `server_side`, `details`, `created_at`, `updated_at`)
VALUES
	(1,'users','users','User','Users','voyager-person','TCG\\Voyager\\Models\\User','TCG\\Voyager\\Policies\\UserPolicy','','',1,0,NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(2,'menus','menus','Menu','Menus','voyager-list','TCG\\Voyager\\Models\\Menu',NULL,'','',1,0,NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(3,'roles','roles','Role','Roles','voyager-lock','TCG\\Voyager\\Models\\Role',NULL,'','',1,0,NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(4,'categories','categories','Category','Categories','voyager-folder','App\\Category',NULL,NULL,'Product Categories',1,1,'{\"order_column\":null,\"order_display_column\":null}','2018-04-13 19:38:12','2018-04-13 19:38:12'),
	(5,'countries','countries','Country','Countries','voyager-world','App\\Country',NULL,NULL,NULL,1,1,'{\"order_column\":null,\"order_display_column\":null}','2018-04-13 19:39:20','2018-04-13 19:39:20'),
	(8,'images','images','Image','Images','voyager-images','App\\Image',NULL,NULL,NULL,1,1,'{\"order_column\":null,\"order_display_column\":null}','2018-04-13 20:18:45','2018-04-13 20:18:45'),
	(11,'products','products','Product','Products','voyager-backpack','App\\Product',NULL,NULL,NULL,1,0,'{\"order_column\":null,\"order_display_column\":null}','2018-04-14 11:03:11','2018-04-14 11:03:11');

/*!40000 ALTER TABLE `data_types` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table images
# ------------------------------------------------------------

DROP TABLE IF EXISTS `images`;

CREATE TABLE `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;

INSERT INTO `images` (`id`, `title`, `product_id`, `created_at`, `updated_at`)
VALUES
	(2,'images/April2018/B2r8KqKqj60jYEWTEWR9.jpg',3,'2018-04-13 23:37:25','2018-04-14 11:13:39'),
	(7,'images/April2018/xOX7w8qbtCvJC22CBTbX.JPG',24,'2018-04-14 11:12:26','2018-04-14 11:12:26'),
	(8,'images/April2018/hM7LoxmoijTk259fci3E.jpg',25,'2018-04-14 11:22:28','2018-04-14 11:22:28');

/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table menu_items
# ------------------------------------------------------------

DROP TABLE IF EXISTS `menu_items`;

CREATE TABLE `menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `menu_items_menu_id_foreign` (`menu_id`),
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;

INSERT INTO `menu_items` (`id`, `menu_id`, `title`, `url`, `target`, `icon_class`, `color`, `parent_id`, `order`, `created_at`, `updated_at`, `route`, `parameters`)
VALUES
	(1,1,'Dashboard','','_self','voyager-boat',NULL,NULL,1,'2018-04-12 18:52:31','2018-04-12 18:52:31','voyager.dashboard',NULL),
	(2,1,'Media','','_self','voyager-images',NULL,NULL,4,'2018-04-12 18:52:31','2018-04-13 21:26:26','voyager.media.index',NULL),
	(3,1,'Users','','_self','voyager-person',NULL,17,1,'2018-04-12 18:52:31','2018-04-13 21:26:23','voyager.users.index',NULL),
	(4,1,'Roles','','_self','voyager-lock',NULL,17,2,'2018-04-12 18:52:31','2018-04-13 21:26:26','voyager.roles.index',NULL),
	(5,1,'Tools','','_self','voyager-tools',NULL,NULL,5,'2018-04-12 18:52:31','2018-04-13 21:26:26',NULL,NULL),
	(6,1,'Menu Builder','','_self','voyager-list',NULL,5,1,'2018-04-12 18:52:31','2018-04-13 19:56:37','voyager.menus.index',NULL),
	(7,1,'Database','','_self','voyager-data',NULL,5,2,'2018-04-12 18:52:31','2018-04-13 19:56:37','voyager.database.index',NULL),
	(8,1,'Compass','','_self','voyager-compass',NULL,5,3,'2018-04-12 18:52:31','2018-04-13 19:56:37','voyager.compass.index',NULL),
	(9,1,'Settings','','_self','voyager-settings',NULL,NULL,6,'2018-04-12 18:52:31','2018-04-13 21:26:26','voyager.settings.index',NULL),
	(10,1,'Hooks','','_self','voyager-hook',NULL,5,4,'2018-04-12 18:52:31','2018-04-13 19:56:37','voyager.hooks',NULL),
	(11,1,'Categories','/admin/categories','_self','voyager-folder',NULL,16,2,'2018-04-13 19:38:12','2018-04-13 21:25:37',NULL,NULL),
	(12,1,'Countries','/admin/countries','_self','voyager-world',NULL,16,3,'2018-04-13 19:39:20','2018-04-13 21:25:37',NULL,NULL),
	(14,1,'Products','/admin/products','_self','voyager-backpack',NULL,16,1,'2018-04-13 20:06:19','2018-04-13 21:25:37',NULL,NULL),
	(15,1,'Images','/admin/images','_self','voyager-images',NULL,16,4,'2018-04-13 20:18:45','2018-04-13 21:25:43',NULL,NULL),
	(16,1,'Rwaq','','_self','voyager-certificate','#000000',NULL,2,'2018-04-13 21:25:10','2018-04-13 21:25:22',NULL,''),
	(17,1,'User Management','','_self','voyager-people','#000000',NULL,3,'2018-04-13 21:26:13','2018-04-13 21:26:20',NULL,'');

/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table menus
# ------------------------------------------------------------

DROP TABLE IF EXISTS `menus`;

CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;

INSERT INTO `menus` (`id`, `name`, `created_at`, `updated_at`)
VALUES
	(1,'admin','2018-04-12 18:52:31','2018-04-12 18:52:31');

/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `migration`, `batch`)
VALUES
	(1,'2014_10_12_000000_create_users_table',1),
	(2,'2014_10_12_100000_create_password_resets_table',1),
	(3,'2016_01_01_000000_add_voyager_user_fields',1),
	(4,'2016_01_01_000000_create_data_types_table',1),
	(5,'2016_05_19_173453_create_menu_table',1),
	(6,'2016_10_21_190000_create_roles_table',1),
	(7,'2016_10_21_190000_create_settings_table',1),
	(8,'2016_11_30_135954_create_permission_table',1),
	(9,'2016_11_30_141208_create_permission_role_table',1),
	(10,'2016_12_26_201236_data_types__add__server_side',1),
	(11,'2017_01_13_000000_add_route_to_menu_items_table',1),
	(12,'2017_01_14_005015_create_translations_table',1),
	(13,'2017_01_15_000000_add_permission_group_id_to_permissions_table',1),
	(14,'2017_01_15_000000_create_permission_groups_table',1),
	(15,'2017_01_15_000000_make_table_name_nullable_in_permissions_table',1),
	(16,'2017_03_06_000000_add_controller_to_data_types_table',1),
	(17,'2017_04_21_000000_add_order_to_data_rows_table',1),
	(18,'2017_07_05_210000_add_policyname_to_data_types_table',1),
	(19,'2017_08_05_000000_add_group_to_settings_table',1),
	(20,'2017_11_26_013050_add_user_role_relationship',1),
	(21,'2017_11_26_014010_drop_permission_groups_table',1),
	(22,'2017_11_26_015000_create_user_roles_table',1),
	(23,'2018_03_11_000000_add_user_settings',1),
	(24,'2018_03_14_000000_add_details_to_data_types_table',1),
	(25,'2018_03_16_000000_make_settings_value_nullable',1),
	(26,'2018_04_12_193425_create_products_table',2),
	(27,'2018_04_13_191650_create_countries_table',2),
	(28,'2018_04_13_191751_create_categories_table',2),
	(29,'2018_04_13_192507_create_images_table',2);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table permission_role
# ------------------------------------------------------------

DROP TABLE IF EXISTS `permission_role`;

CREATE TABLE `permission_role` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_permission_id_index` (`permission_id`),
  KEY `permission_role_role_id_index` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;

INSERT INTO `permission_role` (`permission_id`, `role_id`)
VALUES
	(1,1),
	(2,1),
	(3,1),
	(4,1),
	(5,1),
	(6,1),
	(7,1),
	(8,1),
	(9,1),
	(10,1),
	(11,1),
	(12,1),
	(13,1),
	(14,1),
	(15,1),
	(16,1),
	(17,1),
	(18,1),
	(19,1),
	(20,1),
	(21,1),
	(22,1),
	(23,1),
	(24,1),
	(25,1),
	(26,1),
	(27,1),
	(28,1),
	(29,1),
	(30,1),
	(31,1),
	(32,1),
	(33,1),
	(34,1),
	(35,1),
	(36,1),
	(47,1),
	(48,1),
	(49,1),
	(50,1),
	(51,1),
	(62,1),
	(63,1),
	(64,1),
	(65,1),
	(66,1);

/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `permissions`;

CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_key_index` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;

INSERT INTO `permissions` (`id`, `key`, `table_name`, `created_at`, `updated_at`)
VALUES
	(1,'browse_admin',NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(2,'browse_bread',NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(3,'browse_database',NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(4,'browse_media',NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(5,'browse_compass',NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(6,'browse_menus','menus','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(7,'read_menus','menus','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(8,'edit_menus','menus','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(9,'add_menus','menus','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(10,'delete_menus','menus','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(11,'browse_roles','roles','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(12,'read_roles','roles','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(13,'edit_roles','roles','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(14,'add_roles','roles','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(15,'delete_roles','roles','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(16,'browse_users','users','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(17,'read_users','users','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(18,'edit_users','users','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(19,'add_users','users','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(20,'delete_users','users','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(21,'browse_settings','settings','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(22,'read_settings','settings','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(23,'edit_settings','settings','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(24,'add_settings','settings','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(25,'delete_settings','settings','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(26,'browse_hooks',NULL,'2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(27,'browse_categories','categories','2018-04-13 19:38:12','2018-04-13 19:38:12'),
	(28,'read_categories','categories','2018-04-13 19:38:12','2018-04-13 19:38:12'),
	(29,'edit_categories','categories','2018-04-13 19:38:12','2018-04-13 19:38:12'),
	(30,'add_categories','categories','2018-04-13 19:38:12','2018-04-13 19:38:12'),
	(31,'delete_categories','categories','2018-04-13 19:38:12','2018-04-13 19:38:12'),
	(32,'browse_countries','countries','2018-04-13 19:39:20','2018-04-13 19:39:20'),
	(33,'read_countries','countries','2018-04-13 19:39:20','2018-04-13 19:39:20'),
	(34,'edit_countries','countries','2018-04-13 19:39:20','2018-04-13 19:39:20'),
	(35,'add_countries','countries','2018-04-13 19:39:20','2018-04-13 19:39:20'),
	(36,'delete_countries','countries','2018-04-13 19:39:20','2018-04-13 19:39:20'),
	(47,'browse_images','images','2018-04-13 20:18:45','2018-04-13 20:18:45'),
	(48,'read_images','images','2018-04-13 20:18:45','2018-04-13 20:18:45'),
	(49,'edit_images','images','2018-04-13 20:18:45','2018-04-13 20:18:45'),
	(50,'add_images','images','2018-04-13 20:18:45','2018-04-13 20:18:45'),
	(51,'delete_images','images','2018-04-13 20:18:45','2018-04-13 20:18:45'),
	(62,'browse_products','products','2018-04-14 11:03:11','2018-04-14 11:03:11'),
	(63,'read_products','products','2018-04-14 11:03:11','2018-04-14 11:03:11'),
	(64,'edit_products','products','2018-04-14 11:03:11','2018-04-14 11:03:11'),
	(65,'add_products','products','2018-04-14 11:03:11','2018-04-14 11:03:11'),
	(66,'delete_products','products','2018-04-14 11:03:11','2018-04-14 11:03:11');

/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table products
# ------------------------------------------------------------

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `price` int(11) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;

INSERT INTO `products` (`id`, `title`, `text`, `price`, `is_active`, `user_id`, `country_id`, `category_id`, `created_at`, `updated_at`)
VALUES
	(3,'أيفون ٧','أيفون ٧ أيفون ٧ أيفون ٧',1004,1,3,2,1,'2018-04-14 11:07:00','2018-04-14 11:09:24'),
	(24,'كابرس LTZ 2008 ثمانيه سلندر','كابرس 2008 LTZ \r\nاللون اسود بدون فتحه وجلد \r\nالمكينه -والقير-والمكيف-سليم ولله الحمد \r\nوكذلك الصدامات يبغى لها رش وفيه دقات بسيطة موضحة في الصور البدي سليم من السمكرة الموتر ماقد انرش نهائي يحتاجله كفرات وقطع استهلاكيه بسيطه حدي اعلى سوم الرجاء عدم بخس السلعه ولايسوم الاصامل',10000,1,3,2,2,'2018-04-14 11:10:53','2018-04-14 11:10:53'),
	(25,'شقق تمليك بجدة','يتوفر لدينا شقق وفلل وعمائر للتمليك بنظام الدفع كاش واقساط ونظام الاستثمار.\r\n*حاصلة على تصريح وزارة الاسكان بضمان اتحاد الملاك من الوزارة ومطابق للمواصفات والكود السعودي* \r\nهدايا حصريه ولفتره محدودة لدى عمائر النخبة لعملائنا المميزين:\r\n**عند تملكك بعمائر النخبة تحصل على 3 كوبونات هدايا:\r\nالكوبون الاول:\r\nخصم 5%\r\nالكوبون الثاني :\r\nمطبخ بقيمة 15000 ريال هدية\r\nالكوبون الثالث:\r\nمفروشات من اي هوم بقيمة 5000 ريال من اختيارك\r\n\r\n\r\n**نظام الاستثمار:\r\nاذا اردت ان تمتلك شقه وبها مستأجر ستعود عليك بعائد سنوي بقيمة خمسة بالمئة (5%) من قيمة الشقة.....\r\n\r\n\r\nمايميزنا:\r\n*الارضيات رخام بوتشينو وامبرادور ايطالي .....\r\n*بورسلان اسباني نخب اول فاخر\r\n*سيراميك اسباني نخب اول للحمامات فقط....\r\n*جميع تمديدات الكهرباء مطابقة للمواصفات السعودية الأمريكية مع ضمان سنتين .....\r\n*المبنى مجهز بتمديدات الاتصالات و الانترنت لكل شقه و فيلا...\r\n*يوجد صرف صحي بالمنطقة...\r\n*مصاعد تايسون او ماك بورصة اسبانية \r\nضمان سنتين على الكهرباء والسباكة ...\r\n*يوجد نظام إتحاد الملاك بكل العمائر...\r\n\r\n\r\n**نظام الشقق//\r\n* نظام شقق 3 غرف وتوابعها بمساحة 125 متر بالفيصلية خلف الصيرفي المول....\r\n\r\n*نظام شقق 4 غرف وتوابعها بمساحة 170 متر مدخلين و 164 متر مدخل واحد في العزيزية خلف المحكمة.\r\n\r\n\r\n\r\n* نظام شقق خمس غرف وتوابعها بمساحة 216 متر في العزيزية خلف المحكمة.....\r\n\r\n\r\n* نظام شقق خمس غرف وتوابعها بمساحة 190 متر في الروضة....\r\n\r\n\r\n* نظام روف دورين 13 غرفة 8 حمامات بمساحة 900 متر في حي العزيزية.....\r\n\r\n\r\n* نظام فله تحت التشطيب بالحمدانية بمساحة ارض 300 متر ومساحة البناء 868 متر. في الحمدانية',100000,1,4,2,3,'2018-04-14 11:21:20','2018-04-14 16:50:11'),
	(26,'Veritatis et architecto explicabo. Sed id error at culpa. Voluptates qui deserunt quas rerum.','Totam quod omnis itaque aliquam. Quia est qui consequuntur odit repudiandae. Ipsam ipsum quia natus illum. Illum et debitis quam.',976,0,1,10,1,NULL,'2018-04-14 11:43:22'),
	(27,'Consequatur sint fugit perspiciatis mollitia totam incidunt. Fugit quam quia sunt.','Qui temporibus ea sed inventore dolorem. Sed debitis consectetur porro veritatis est minima.',3723,0,1,3,3,NULL,NULL),
	(28,'Blanditiis sunt beatae vel dolores ipsa harum dignissimos. At id unde ullam nulla.','Voluptas nam animi voluptatum et. Nisi odio odit voluptatem saepe. Est quae iusto excepturi animi ea qui. Esse iusto corrupti reprehenderit aperiam sed quidem omnis.',8509,0,1,5,2,NULL,NULL),
	(29,'Necessitatibus ipsum qui eveniet facilis provident sint aut. Sed sunt voluptatem dolor.','Corporis voluptatem temporibus et ut. Qui minus atque inventore esse. Dolorum et omnis incidunt ut quia in. Ducimus ut voluptas ab et.',3675,0,1,9,3,NULL,NULL),
	(30,'Praesentium provident nihil quia vel quis placeat. Facilis odio id non quis esse.','Placeat qui quia reprehenderit. Voluptas enim corporis doloribus laborum qui alias earum. Deleniti assumenda ipsam rerum at facilis rerum. Sapiente temporibus quo qui aut ratione.',5546,0,1,1,3,NULL,NULL),
	(31,'Consequatur corrupti sapiente rem sit perspiciatis atque. Est voluptas quidem quia quas.','Ipsum nemo voluptate ex doloremque aperiam et doloremque. Illo sed corrupti fugiat vitae ut suscipit. Saepe adipisci quod quam. Non et qui voluptatum autem corporis eos.',1276,0,1,10,1,NULL,NULL),
	(32,'Vel reprehenderit rerum numquam veniam rerum. Rerum dolores placeat recusandae quia.','Unde quasi accusantium ea ut quia at non. Sapiente aspernatur sunt sit veniam sunt. Veritatis officia qui laboriosam. Quia vel laborum molestiae illo.',1765,0,1,10,4,NULL,'2018-04-14 11:43:37'),
	(33,'Qui quasi alias non ad est. Ducimus eveniet enim voluptate et ut et. Eaque rerum soluta cumque.','Corporis ullam illum maiores illum. Perferendis dolor eligendi nesciunt magnam illum. Tempora corrupti expedita eveniet maiores quibusdam placeat accusamus qui.',3697,0,1,3,6,NULL,'2018-04-14 11:43:51'),
	(34,'Quas quis rerum unde laudantium ducimus corporis qui cumque. Excepturi velit saepe recusandae.','Eius saepe sed cum magnam libero ipsa voluptas. Voluptatem consequatur facilis et iste. Quo exercitationem minus nihil explicabo et quaerat. Ducimus dolores ea incidunt enim voluptatem fuga.',1541,0,1,5,2,NULL,NULL),
	(35,'Minima assumenda aut illo sint repellendus. Cupiditate fuga ut temporibus voluptatem in in eos.','A totam dolorum nihil maxime omnis tempora. Non rem odit expedita doloremque temporibus deserunt id. In voluptatem blanditiis error aut repellendus.',4065,0,1,7,3,NULL,NULL),
	(36,'Quo et perferendis quia maiores. Necessitatibus sint sunt id atque.','Non praesentium saepe labore rem et modi. Dolor est praesentium aut dolores veniam asperiores vel quidem. Ullam voluptate qui sint animi ullam. Deserunt dolore quidem et optio accusantium.',2684,0,1,4,3,NULL,NULL),
	(37,'Nihil quae veniam maxime exercitationem non. Voluptatem sint illum consectetur tempore libero.','Voluptates fugit voluptatibus quae earum omnis voluptatem possimus. Eum dolorem deleniti eum molestias.',7204,0,1,7,3,NULL,NULL),
	(38,'Ratione non quos aut quia ullam ratione numquam. Ut sint modi nulla alias velit.','Sed quod dolorem eius sed. Est sint molestias consequatur consequatur. Reiciendis et est veritatis vel sed consequatur adipisci. Ut nemo est laboriosam doloremque qui.',5437,0,1,5,1,NULL,NULL),
	(39,'Et qui nulla itaque delectus labore ut dolorum. Natus ab ad itaque. Similique velit veniam ad a.','Sint pariatur repellat natus minus consequatur nobis veritatis est. Dolores temporibus fugiat itaque ut et. Eos dolorem ducimus nesciunt esse. Sint illo a qui quas. Et et dicta earum.',8464,0,1,7,5,NULL,'2018-04-14 11:44:10'),
	(40,'Voluptatem maiores soluta voluptatibus praesentium facilis. Exercitationem non qui dolor.','Qui rerum itaque accusamus quod assumenda. Reiciendis aperiam doloremque debitis fugit. Sed quis suscipit dolor placeat.',1987,0,1,8,3,NULL,NULL),
	(41,'Dolorum fuga est reprehenderit explicabo. Qui fugit nemo rerum.','Laudantium ab maiores est ut. Nobis pariatur quidem unde sunt laboriosam velit velit. Eos aliquam fugiat quos hic amet quo. Nisi animi autem expedita sed et vel placeat.',9500,0,1,10,3,NULL,NULL),
	(42,'Aut qui dolore minima molestiae. Omnis quia rerum excepturi maiores fuga.','Totam labore magni id non distinctio quod eius fugiat. Est non dicta dolor omnis.',3710,0,1,8,6,NULL,'2018-04-14 11:44:21'),
	(43,'Ipsa harum minima soluta non. Sed ut est itaque praesentium dolorem veniam nihil.','Consectetur animi dicta eum sit. Aut porro quas sed neque ea aut impedit. Aperiam omnis neque mollitia vitae perferendis vero fuga.',4618,0,1,9,6,NULL,'2018-04-14 11:44:57'),
	(44,'Officiis laudantium autem at hic. Non quaerat quia praesentium distinctio.','Labore et et perspiciatis maiores quos cum est. Qui quia consequuntur suscipit sit consequatur quas. Voluptate provident perspiciatis blanditiis ducimus unde accusamus.',4090,0,1,4,4,NULL,'2018-04-14 11:44:46'),
	(45,'Quae et et est ex nemo. Aut et ea ullam ut aliquam similique.','Dolor voluptatem ut vel aut saepe occaecati quia. Nam saepe veritatis dolores rem cupiditate. Quod voluptatum perspiciatis optio vel dolores aut. Quod et suscipit iste ut quos dolorum.',5757,0,1,8,5,NULL,'2018-04-14 11:44:32');

/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;

INSERT INTO `roles` (`id`, `name`, `display_name`, `created_at`, `updated_at`)
VALUES
	(1,'admin','Administrator','2018-04-12 18:52:31','2018-04-12 18:52:31'),
	(2,'user','Normal User','2018-04-12 18:52:31','2018-04-12 18:52:31');

/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table settings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `details` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '1',
  `group` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;

INSERT INTO `settings` (`id`, `key`, `display_name`, `value`, `details`, `type`, `order`, `group`)
VALUES
	(1,'site.title','Site Title','Site Title','','text',1,'Site'),
	(2,'site.description','Site Description','Site Description','','text',2,'Site'),
	(3,'site.logo','Site Logo','','','image',3,'Site'),
	(4,'site.google_analytics_tracking_id','Google Analytics Tracking ID','','','text',4,'Site'),
	(5,'admin.bg_image','Admin Background Image','','','image',5,'Admin'),
	(6,'admin.title','Admin Title','Voyager','','text',1,'Admin'),
	(7,'admin.description','Admin Description','Welcome to Voyager. The Missing Admin for Laravel','','text',2,'Admin'),
	(8,'admin.loader','Admin Loader','','','image',3,'Admin'),
	(9,'admin.icon_image','Admin Icon Image','','','image',4,'Admin'),
	(10,'admin.google_analytics_client_id','Google Analytics Client ID (used for admin dashboard)','','','text',1,'Admin');

/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table translations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `translations`;

CREATE TABLE `translations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int(10) unsigned NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table user_roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_roles`;

CREATE TABLE `user_roles` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `user_roles_user_id_index` (`user_id`),
  KEY `user_roles_role_id_index` (`role_id`),
  CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;

INSERT INTO `user_roles` (`user_id`, `role_id`)
VALUES
	(3,2),
	(4,2);

/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `avatar`, `password`, `remember_token`, `settings`, `created_at`, `updated_at`)
VALUES
	(1,1,'webmaster','webmaster@admin.com','users/April2018/UXnY95GgpcDEBRkYJ38D.jpg','$2y$10$goE0dugvxZTDL3Y9Bd3MquMIHeKmB3q4IZ9C9970B9.ptlF9wLgB6',NULL,'{\"locale\":\"en\"}','2018-04-12 18:56:40','2018-04-12 19:21:36'),
	(3,2,'ali','ali@admin.com','users/April2018/Lx37nmqR2L4RGJs05pA5.png','$2y$10$JvMILiYKsqxF.cr/sqeNiOCUvzYEIQ0D76tDSQk9dongKbu66ol0i',NULL,'{\"locale\":\"en\"}','2018-04-14 01:21:14','2018-04-14 01:21:14'),
	(4,2,'خالد','khaled@admin.com','users/April2018/oH5wHNTRw9KUwUlDRopI.png','$2y$10$Ajp55I0uMJvHCTSucxNeJ.LK0xzvydb.7VlCPW0hQF3FzFxkd7VIm',NULL,'{\"locale\":\"en\"}','2018-04-14 16:49:52','2018-04-14 16:49:52');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
